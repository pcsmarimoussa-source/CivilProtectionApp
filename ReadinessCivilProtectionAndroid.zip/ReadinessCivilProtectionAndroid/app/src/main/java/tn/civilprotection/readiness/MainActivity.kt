package tn.civilprotection.readiness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Equipment(
    val id: String = "",
    val name: String = "",
    val category: String = "معدات",
    val quantity: Long = 1,
    val condition: String = "سليم",
    val notes: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { ReadinessApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadinessApp() {
    val db = remember { FirebaseFirestore.getInstance() }
    val auth = remember { FirebaseAuth.getInstance() }
    var signedIn by remember { mutableStateOf(auth.currentUser != null) }
    var items by remember { mutableStateOf(listOf<Equipment>()) }
    var error by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("الرئيسية") }

    LaunchedEffect(Unit) {
        if (auth.currentUser == null) {
            auth.signInAnonymously()
                .addOnSuccessListener { signedIn = true }
                .addOnFailureListener { error = "تعذر الاتصال بالخدمة السحابية: ${it.localizedMessage}" }
        } else signedIn = true
    }

    DisposableEffect(signedIn) {
        if (!signedIn) return@DisposableEffect onDispose { }
        val registration = db.collection("equipment")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) error = "خطأ في تحميل البيانات: ${e.localizedMessage}"
                else items = snapshot?.documents?.map { d ->
                    Equipment(
                        id = d.id,
                        name = d.getString("name") ?: "",
                        category = d.getString("category") ?: "معدات",
                        quantity = d.getLong("quantity") ?: 1,
                        condition = d.getString("condition") ?: "سليم",
                        notes = d.getString("notes") ?: ""
                    )
                } ?: emptyList()
            }
        onDispose { registration.remove() }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF123B5D),
            secondary = androidx.compose.ui.graphics.Color(0xFFE05A36),
            background = androidx.compose.ui.graphics.Color(0xFFF4F6F8)
        )) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("متابعة جاهزية الفرقة", fontWeight = FontWeight.Bold)
                                Text("الحماية المدنية", style = MaterialTheme.typography.labelSmall)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            titleContentColor = androidx.compose.ui.graphics.Color.White
                        )
                    )
                },
                floatingActionButton = {
                    FloatingActionButton(onClick = { showAdd = true }) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة")
                    }
                },
                bottomBar = {
                    NavigationBar {
                        listOf("الرئيسية", "التجهيزات", "العربات", "الأعوان", "التفقد").forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        when (tab) {
                                            "التجهيزات" -> Icons.Default.Inventory2
                                            "العربات" -> Icons.Default.DirectionsCar
                                            "الأعوان" -> Icons.Default.Groups
                                            "التفقد" -> Icons.Default.Assignment
                                            else -> Icons.Default.Assignment
                                        }, contentDescription = tab
                                    )
                                },
                                label = { Text(tab) }
                            )
                        }
                    }
                },
                containerColor = MaterialTheme.colorScheme.background
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                    if (!signedIn) {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text("جاري الاتصال بقاعدة البيانات السحابية…")
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SummaryCard("مجموع المعدات", items.size.toString(), Modifier.weight(1f))
                            SummaryCard("معدات سليمة", items.count { it.condition == "سليم" }.toString(), Modifier.weight(1f))
                            SummaryCard("تحتاج متابعة", items.count { it.condition != "سليم" }.toString(), Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(
                            when (selectedTab) {
                                "الرئيسية" -> "ملخص الجاهزية"
                                "التجهيزات" -> "سجل التجهيزات والمعدات"
                                "العربات" -> "قسم العربات والآليات"
                                "الأعوان" -> "قسم الأعوان"
                                else -> "سجل عمليات التفقد"
                            },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(8.dp))
                        if (selectedTab == "التجهيزات" || selectedTab == "الرئيسية") {
                            if (items.isEmpty()) {
                                Card(shape = RoundedCornerShape(16.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Text("لا توجد تجهيزات مسجلة بعد", fontWeight = FontWeight.SemiBold)
                                        Text("اضغط على زر + لإضافة أول عنصر", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            } else {
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(items, key = { it.id }) { item ->
                                        EquipmentRow(item)
                                    }
                                }
                            }
                        } else {
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Text(
                                    "هذا القسم مهيأ للتوسعة في النسخة التالية. يمكن حالياً تسجيل التجهيزات ومتابعتها سحابياً.",
                                    Modifier.padding(18.dp),
                                    textAlign = TextAlign.Start
                                )
                            }
                        }
                        if (error.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("المزامنة السحابية: ${if (signedIn) "متصل" else "غير متصل"}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddEquipmentDialog(
            onDismiss = { showAdd = false },
            onSave = { name, category, quantity, condition, notes ->
                val data = hashMapOf(
                    "name" to name,
                    "category" to category,
                    "quantity" to quantity,
                    "condition" to condition,
                    "notes" to notes,
                    "createdAt" to System.currentTimeMillis()
                )
                db.collection("equipment").add(data)
                    .addOnFailureListener { error = "تعذر حفظ العنصر: ${it.localizedMessage}" }
                showAdd = false
            }
        )
    }
}

@Composable
fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun EquipmentRow(item: Equipment) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.name, fontWeight = FontWeight.Bold)
                Text("${item.category} • الكمية: ${item.quantity}", style = MaterialTheme.typography.bodySmall)
                if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            }
            AssistChip(
                onClick = {},
                label = { Text(item.condition) },
                colors = AssistChipDefaults.assistChipColors(
                    labelColor = if (item.condition == "سليم") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEquipmentDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Long, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("معدات إطفاء") }
    var quantity by remember { mutableStateOf("1") }
    var condition by remember { mutableStateOf("سليم") }
    var notes by remember { mutableStateOf("") }
    val categories = listOf("معدات إطفاء", "معدات إنقاذ", "معدات إسعاف", "اتصالات", "معدات وقاية", "أخرى")
    val conditions = listOf("سليم", "معطّب", "ناقص", "يحتاج صيانة")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة تجهيز جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم التجهيز") }, singleLine = true)
                var categoryExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("الصنف") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                        categories.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { category = option; categoryExpanded = false }) }
                    }
                }
                OutlinedTextField(quantity, { quantity = it.filter(Char::isDigit) }, label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                var conditionExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = conditionExpanded, onExpandedChange = { conditionExpanded = !conditionExpanded }) {
                    OutlinedTextField(condition, {}, readOnly = true, label = { Text("الحالة") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = conditionExpanded, onDismissRequest = { conditionExpanded = false }) {
                        conditions.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { condition = option; conditionExpanded = false }) }
                    }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, minLines = 2)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && (quantity.toLongOrNull() ?: 0) > 0,
                onClick = { onSave(name.trim(), category, quantity.toLong(), condition, notes.trim()) }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
